package view;

import model.Book;
import model.User;

import java.util.Scanner;

public class View {
    private static Scanner input = new Scanner(System.in);

    public String getCommand() {
        return input.nextLine();
    }

    public void logBorrowRequestResultMassage(boolean accepted , User user , Book book) {
        if (accepted) {
            log("Borrow : User " +  user.getName() + " book: " + book.getName());
        } else {
            log("there is a problem ... .");
        }
    }

    public void logGiveBackRequestResultMassage(boolean accepted , User user , Book book) {
        if (accepted) {
            log("Give back : User " +  user.getName() + "and book: " + book.getName());
        } else {
            log("there is a problem ... .");
        }
    }

    public void logNewUserRequestResultMassage(User user) {
        log("User : " + user.getName() + " added." );
    }

    public void logNewBookRequestResultMassage(Book book) {
        log("book : " + book.getName() + " added." );

    }
    private void log(String string) {
        System.out.println(string);
    }

    public void logInvalidRequest() {
        log("Your request is invalid");
    }
}
