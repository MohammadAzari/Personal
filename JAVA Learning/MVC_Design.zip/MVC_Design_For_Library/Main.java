import controler.LibraryController;

public class Main {
    public static void main(String[] args) {
        LibraryController.getInstance().listenForCommand(args);
    }
}
