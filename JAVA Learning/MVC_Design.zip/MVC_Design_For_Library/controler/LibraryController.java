package controler;

import model.Book;
import model.Library;
import model.User;
import model.requests.*;
import view.View;

public class LibraryController {
    private static LibraryController controller;
    private View view;
    private Library library;
    private CommandAnalyzer commandAnalyzer;
    private LibraryController() {
        view = new View();
        library = Library.getInstance();
        commandAnalyzer = CommandAnalyzer.getInstance();
    }
    public static LibraryController getInstance()  {
        if (controller == null) {
            controller = new LibraryController();
        }
        return controller;
    }


    public void listenForCommand(String[] args) {
        boolean isFinish = false;
        while (!isFinish) {
            String command = view.getCommand().trim();
            Request request = commandAnalyzer.getRequest(command);
            if (request instanceof AddNewBookRequest) {
                AddNewBookAction((AddNewBookRequest) request);
            } else if  (request instanceof BorrowBookRequest) {
                BorrowBookAction((BorrowBookRequest) request);
            } else if (request instanceof GiveBackBookRequest) {
                giveBackAction(request);
            } else if (request instanceof SignNewUserRequest) {
                addNewUserAction((SignNewUserRequest) request);
            } else if (request instanceof ExitRequest) {
                isFinish = true;
            } else {
                view.logInvalidRequest();
            }
        }
    }

    private void AddNewBookAction(AddNewBookRequest request) {
        Book book = addNewBook(request);
        view.logNewBookRequestResultMassage(book);
    }

    private void BorrowBookAction(BorrowBookRequest request) {
        if (borrowBook(request)) {
            view.logBorrowRequestResultMassage(true ,
                    getUser(request.getUserId()),
                    getBook(request.getBookId()));
        } else {
            view.logBorrowRequestResultMassage(false , null , null);
        }
    }

    private void addNewUserAction(SignNewUserRequest request) {
        User user = addNewUser(request);
        view.logNewUserRequestResultMassage(user);
    }

    private void giveBackAction(Request request) {
        if (GiveBack((GiveBackBookRequest) request)) {
           view.logGiveBackRequestResultMassage(true ,
                   getUser(((GiveBackBookRequest) request).getUserId()),
                   getBook(((GiveBackBookRequest) request).getBookId()));
        } else {
            view.logGiveBackRequestResultMassage(false , null ,null);
        }
    }

    private boolean GiveBack(GiveBackBookRequest request) {
        if (hasUser(request.getUserId()) && hasBook(request.getBookId())) {
            if (isGiveBackValid(request)) {
                library.getBorrowedBooksBookUser().remove(getBook(request.getBookId()));
                return true;
            }
        }
        return false;
    }

    private boolean isGiveBackValid(GiveBackBookRequest request) {
        return library.getBorrowedBooksBookUser().get(getBook(request.getBookId())) != null && library.getBorrowedBooksBookUser().get(getBook(request.getBookId())).equals(getUser(request.getUserId()));
    }

    private boolean borrowBook(BorrowBookRequest request) {
        if (hasBook(request) && hasUser(request.getUserId())) {
            library.getBorrowedBooksBookUser().put(library.getBooks().get(request.getBookId()) ,  library.getUsers().get(request.getUserId()));
            return true;
        }
        return false;
    }

    private boolean hasUser(String id) {
        return library.getUsers().containsKey(id);
    }

    private boolean hasBook(String id) {
        return library.getBooks().containsKey(id);
    }

    private Book getBook(String id) {
        return library.getBooks().get(id);
    }

    private User getUser(String id) {
        return library.getUsers().get(id);
    }

    private boolean hasBook(BorrowBookRequest request) {
        return library.getBorrowedBooksBookUser().get(library.getBooks().get(request.getBookId())) == null && hasBook(request.getBookId());
    }

    private User addNewUser(SignNewUserRequest request) {
        User user = new User(request.getUserName(), request.getUserId());
        library.getUsers().put(request.getUserId() , user);
        return user;
    }

    private Book addNewBook(AddNewBookRequest request) {
        Book book = new Book(request.getName(), request.getISBN());
        library.getBooks().put(request.getISBN() , book);
        return book;
    }
}
