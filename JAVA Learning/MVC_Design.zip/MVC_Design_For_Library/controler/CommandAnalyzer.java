package controler;

import model.requests.*;

import java.util.ConcurrentModificationException;

public class CommandAnalyzer {

    public static final String EXIT = "exit";
    private static CommandAnalyzer commandAnalyzer = new CommandAnalyzer();
    //regex of commands
    private static final String NEW_BOOK_REGEX = "new book [a-z]+ [a-z|0-9]+";//String name , String bookId
    private static final String GIVE_BACK_REGEX = "give back [a-z|0-9]+ [a-z|0-9]+";//String User Id , String bookId
    private static final String SIGN_USER_REGEX = "new user [a-z]+ [a-z|0-9]+";//String name , String userId
    private static final String BORROW_BOOK_REGEX = "borrow book [a-z|0-9]+ [a-z|0-9]+";//String name , String userId

    private CommandAnalyzer() {
    }

    public static CommandAnalyzer getInstance() {
        return commandAnalyzer;
    }

    public Request getRequest(String command) {
        if (command.matches(NEW_BOOK_REGEX)) {
            String[] params = command.split(" ");
            return new AddNewBookRequest(params[2] , params[3]);
        } else if (command.matches(GIVE_BACK_REGEX)) {
            String[] params = command.split(" ");
            return new GiveBackBookRequest(params[2] , params[3]);
        } else if (command.matches(SIGN_USER_REGEX)) {
            String[] params = command.split(" ");
            return new SignNewUserRequest(params[2] , params[3]);
        } else if (command.matches(BORROW_BOOK_REGEX)) {
            String[] params = command.split(" ");
            return new BorrowBookRequest(params[2] , params[3]);
        } else if (command.matches(EXIT)) {
            return new ExitRequest();
        }
        return null;
    }

}
