package model;

import java.util.HashMap;

public class Library {
    private static Library libraryInstance;
    private HashMap<String , Book> books;
    private HashMap<String , User> users;
    private HashMap<Book , User> borrowedBooksBookUser;

    public HashMap<Book, User> getBorrowedBooksBookUser() {
        return borrowedBooksBookUser;
    }

    public void setBorrowedBooksBookUser(HashMap<Book, User> borrowedBooksBookUser) {
        this.borrowedBooksBookUser = borrowedBooksBookUser;
    }

    public static Library getLibraryInstance() {
        return libraryInstance;
    }

    public static void setLibraryInstance(Library libraryInstance) {
        Library.libraryInstance = libraryInstance;
    }

    public HashMap<String, Book> getBooks() {
        return books;
    }

    public void setBooks(HashMap<String, Book> books) {
        this.books = books;
    }

    public HashMap<String, User> getUsers() {
        return users;
    }

    public void setUsers(HashMap<String, User> users) {
        this.users = users;
    }

    private Library() {
        borrowedBooksBookUser = new HashMap<>();
        users = new HashMap<>();
        books = new HashMap<>();
    }

    public static Library getInstance() {
        if (libraryInstance == null)
            libraryInstance = new Library();
        return libraryInstance;
    }
}
