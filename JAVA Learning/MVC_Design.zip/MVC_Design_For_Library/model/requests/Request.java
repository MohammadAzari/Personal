package model.requests;

public class Request {
}
