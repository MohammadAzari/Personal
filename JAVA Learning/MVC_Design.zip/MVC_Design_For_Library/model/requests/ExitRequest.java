package model.requests;

public class ExitRequest extends Request {
}
