import java.util.Scanner;

public class DirtyCode {

    private static final int BILL_COUNT = 5;
    private static final String VALID_MESSAGE = "your bill and payment id are correct";
    private static final String DATA_INVALID_MESSAGE = "your data is invalid because of error code";
    private static final String CODE_101 = "101 - pay attention more";
    private static final String CODE_102 = "102 - check your mind";
    private static final String CODE_103 = "103 - just error";
    private static final String CODE_104 = "104 - another error";
    private static final String CODE_105 = "105 - tell me soon";

    public static void main(String[] args) {
        boolean isValid = true;
        int numOfInvalidData = 0;
        Scanner input = new Scanner(System.in);
        String[] bills = new String[BILL_COUNT];
        String[] payments = new String[BILL_COUNT];
        for (int i = 0; i < bills.length; i++) {
            bills[i]  = input.next();
            payments[i] = input.next();
            if (isPaymentValid(bills[i], payments[i])) {
                isValid = false;
                numOfInvalidData++;
            }
        }
        if (isValid) {
            System.out.println(VALID_MESSAGE);
        } else {
            switch (numOfInvalidData) {
                case 1:
                    logError(CODE_101);
                    break;
                case 2:
                    logError(CODE_102);
                    break;
                case 3:
                    logError(CODE_103);
                    break;
                case 4:
                    logError(CODE_104);
                    break;
                case 5:
                    logError(CODE_105);
                    break;
            }
        }
    }

    private static void logError(String errorCode) {
        System.out.println(DATA_INVALID_MESSAGE + " " + errorCode);
    }

    private static boolean isPaymentValid(String billId, String paymentId) {
        return Integer.parseInt(billId.substring(0, 1))
                + Integer.parseInt(paymentId.substring(2, 4)) % 5 != 0;
    }
}
