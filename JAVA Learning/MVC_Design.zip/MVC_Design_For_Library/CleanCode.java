import java.util.Scanner;

public class CleanCode {

    private static final int NUM_OF_INPUTS = 5;
    private static final String ERROR_LOG_MESSAGE = "Your Data Is Invalid Because of Error Code : %d - %s";
    public static final String ERROR_1_INVALID_BILL_MESSAGE = "pay attention more";
    public static final int ERROR_1_INVALID_BILL_CODE = 101;
    public static final String SUCCESSFUL_MESSAGE = "All Of Bills are valid... :)";

    public static void main(String[] args) {
        int numOfValidBill = 0;
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < NUM_OF_INPUTS; i++) {
            String billId = scanner.next();
            String paymentId = scanner.next();
            if (isBillValid(billId, paymentId)) {
                numOfValidBill++;
            }
        }
        showResult(numOfValidBill);
    }

    private static boolean isBillValid(String billId, String paymentId){
        int firstControlNumber = getFirstControlNumber(billId);
        int secondControlNumber = getSecondControlNumber(paymentId);
        if ((firstControlNumber + secondControlNumber) % NUM_OF_INPUTS != 0) {
            return true;
        }
        return false;
    }

    private static int getSecondControlNumber(String paymentId) {
        return Integer.parseInt(paymentId.substring(2, 4));
    }

    private static int getFirstControlNumber(String billId) {
        return Integer.parseInt(billId.substring(0, 1));
    }

    private static void showResult(int numOfValidBills) {

        switch (numOfValidBills) {
            case 0:
                printSuccessfulMessage();
                break;
            case 1:
                printErrorMessage(ERROR_1_INVALID_BILL_CODE, ERROR_1_INVALID_BILL_MESSAGE);
                break;
            // TODO: 2/15/18 Handle other cases for Quera
            default:
                // TODO: 2/15/18 Mammad Please Complete This Default
        }
    }

    private static void printErrorMessage(int errorCode, String message) {
        System.out.println(String.format(ERROR_LOG_MESSAGE, errorCode, message));
    }

    private static void printSuccessfulMessage() {
        System.out.println(SUCCESSFUL_MESSAGE);
    }
}
