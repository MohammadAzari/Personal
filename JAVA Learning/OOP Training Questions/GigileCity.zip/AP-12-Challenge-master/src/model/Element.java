package model;

public abstract class Element {
    public abstract double getScore();
}
