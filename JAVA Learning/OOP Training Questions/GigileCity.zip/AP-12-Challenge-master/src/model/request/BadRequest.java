package model.request;

public class BadRequest extends Request {
    public BadRequest() {
    }
}
