package model.request;

public class DoneRequest extends Request {
    public DoneRequest() {
    }

}
