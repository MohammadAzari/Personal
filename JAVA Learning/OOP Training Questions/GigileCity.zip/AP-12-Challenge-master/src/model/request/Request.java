package model.request;

public class Request {

    public Request() {
    }

}
