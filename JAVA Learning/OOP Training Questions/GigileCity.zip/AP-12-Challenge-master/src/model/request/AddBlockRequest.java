package model.request;

public class AddBlockRequest extends Request {

    public AddBlockRequest() {
    }


}
