package model.request;

public class YieldRequest extends Request {

    public YieldRequest() {
    }
}
