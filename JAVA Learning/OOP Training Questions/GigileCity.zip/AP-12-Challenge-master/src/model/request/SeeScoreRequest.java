package model.request;

public class SeeScoreRequest extends Request {

    public SeeScoreRequest() {
    }
}
