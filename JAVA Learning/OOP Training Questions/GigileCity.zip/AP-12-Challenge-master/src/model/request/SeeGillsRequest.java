package model.request;

public class SeeGillsRequest extends Request {

    public SeeGillsRequest() {
    }
}
