import controller.CityController;

public class OurChallenge { public static void main(String[] args) {new CityController().listenForCommand();}}
