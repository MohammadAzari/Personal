package utils;

public class Const {
    public static final Long START_MONEY = 30000L;
    public static final Long START_SCORE = 0L;
    public static final Long START_HOME_CAPACITY = 0L;
    public static final Long START_HOME_UPDATE_INCREASE = 0L;
    public static final Long START_NUMBER_FLOOR = 0L;
    public static final Long START_NUMBER_GILG_PER_FLOOR = 0L;
    public static final Long START_NUMBER_UNITS = 0L;
    public static final double START_MARKET_AMOUNT_SCORE = 1.2;
    public static final Long START_MARKET_AMOUNT_MONEY = 0L;
    public static final Long GILGE_PER_UNIT = 5L;

}
