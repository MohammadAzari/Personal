import java.util.Scanner;
import java.util.regex.Pattern;

//This program was written by "Mohammad Azari" on AP course

public class Q4Prime {

    private static boolean patternChecker(String str){

        Pattern patternOne = Pattern.compile("(\\d{3}\\.){1,2}\\d{2}");
        Pattern patternTwo = Pattern.compile("1\\.000\\.000");
        Pattern patternThree = Pattern.compile("\\d{1,3}");
        Pattern patternFour = Pattern.compile("\\d{1,2}\\.\\d{3}\\.\\d{2}");
        Pattern patternFive = Pattern.compile("\\d{1,3}\\.\\d{2}");
        Pattern patternSix = Pattern.compile("\\d{1,3}\\.\\d{3}");

        if (patternOne.matcher(str).matches()) return true;
        else if (patternTwo.matcher(str).matches()) return true;
        else if (patternThree.matcher(str).matches()) return true;
        else if (patternFour.matcher(str).matches()) return true;
        else if (patternFive.matcher(str).matches()) return true;
        else return patternSix.matcher(str).matches();

    }

    private static int typeIdentifier(String baseStr){

        if (baseStr.matches("(\\d{3}\\.){2}\\d{2}")) return 1;
        else if (baseStr.matches("1\\.000\\.000")) return 2;
        else if (baseStr.matches("\\d{1,3}")) return 3;
        else if (baseStr.matches("\\d{1,2}\\.\\d{3}\\.\\d{2}")) return 4;
        else if (baseStr.matches("\\d{1,3}\\.\\d{2}")) return 5;
        else if (baseStr.matches("\\d{1,3}\\.\\d{3}")) return 6;
        else return 0;

    }

    private static String reverse(String strBase){
        String revStr = "";
        for (int i = strBase.length() - 1 ; i >= 0 ; i--){
            revStr = revStr.concat(Character.toString(strBase.charAt(i)));
        }
        return revStr;
    }

    private static String changeStr(String str) {
        String temp = "";
        str = reverse(str);
        int index = 1;
        for (int i = 0 ; i < str.length() ; i++){
            if (index % 4 == 0){
                temp = temp.concat(".");
                i--;
                index++;
            }
            else {
                temp = temp.concat(Character.toString(str.charAt(i)));
                index++;
            }
        }
        temp = reverse(temp);
        return temp;
    }

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String bill = scanner.nextLine();
        String integer = "";
        int decVal = 0, intVal = 0;
        bill = bill.replaceAll("[a-zA-Z]{1,10}", " ");
        bill = bill.substring(1);
        String[] vals = bill.split(" ");

        for (String val : vals) {
            if (!patternChecker(val)) {
                System.out.println("Invalid Input");
                return;
            }
            else {
                switch (typeIdentifier(val)) {

                    case 0:
                        System.out.println("Invalid Input");
                        return;

                    case 1: { //"(\\d{3}\\.){1,2}\\d{2}"
                        if (val.startsWith("0") || val.endsWith("00")) {
                            System.out.println("Invalid Input");
                            return;
                        }
                        else {
                            String[] tempOne = val.split("\\.");
                            decVal += Integer.parseInt(tempOne[2]);
                            intVal += Integer.parseInt(tempOne[0].concat(tempOne[1]));
                            break;
                        }
                    }

                    case 2: { //"1\\.000\\.000"
                        String[] tempOne = val.split("\\.");
                        for (String aTempOne : tempOne)
                            integer = integer.concat(aTempOne);
                        intVal += Integer.parseInt(integer);
                        integer = "";
                        break;
                    }

                    case 3: { //"\\d{1,3}"
                        if (val.startsWith("0")) {
                            System.out.println("Invalid Input");
                            return;
                        }
                        intVal += Integer.parseInt(val);
                        break;
                    }

                    case 4: { //"\\d{1,2}\\.(\\d{3}\\.){1}\\d{2}"
                        if (val.startsWith("0") || val.endsWith("00")) {
                            System.out.println("Invalid Input");
                            return;
                        }
                        String[] temp = val.split("\\.");
                        intVal += Integer.parseInt(temp[0].concat(temp[1]));
                        decVal += Integer.parseInt(temp[2]);
                        break;
                    }

                    case 5: { //"\\d{1,3}\\.\\d{2}"
                        if (val.endsWith("00")) {
                            System.out.println("Invalid Input");
                            return;
                        } else {
                            String[] strTemp = val.split("\\.");
                            intVal += Integer.parseInt(strTemp[0]);
                            decVal += Integer.parseInt(strTemp[1]);
                        }
                        break;
                    }
                    
                    case 6: { //"\\d{3}\\.\\d{3}"
                        if (val.startsWith("0")) {
                            System.out.println("Invalid Input");
                            return;
                        }
                        String[] temp = val.split("\\.");
                        integer = temp[0].concat(temp[1]);
                        intVal += Integer.parseInt(integer);
                        break;
                    }

                    default:
                        break;

                }

                if (decVal >= 100) {
                    intVal += decVal / 100;
                    decVal = decVal % 100;
                }
            }
        }

        String temp = Integer.toString(intVal);
        temp = changeStr(temp);

        if (decVal == 0)
            System.out.println(temp);
        else
        System.out.printf("%s.%02d", temp,decVal);
        scanner.close();
    }
}
