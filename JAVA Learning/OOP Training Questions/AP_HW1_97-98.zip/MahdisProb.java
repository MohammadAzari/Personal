import java.util.Scanner;
// program was written by "Mohammad Azari" on AP course
public class MahdisProb {

    private static boolean isInRadius(double[] pointOfIntersect, double radius) {
        double distance = Math.sqrt(Math.pow(pointOfIntersect[0], 2) + Math.pow(pointOfIntersect[1], 2));
        return distance < radius;
    }

    private static double[] findIntersection(double[] coefsOne, double[] coefsTwo) {
        double[] intersectionPoint = new double[2];
        double determinant = (coefsOne[0] * coefsTwo[1]) - (coefsTwo[0] * coefsOne[1]);
        // det = (a1 * b2) - (a2 * b1)
        intersectionPoint[0] = (((coefsTwo[2] * coefsOne[1]) - (coefsOne[2] * coefsTwo[1])) / determinant);
        // x = ((c2 * b1) - (c1 * b2)) / det
        intersectionPoint[1] = (((coefsOne[2] * coefsTwo[0]) - (coefsTwo[2] * coefsOne[0])) / determinant);
        // y = (c1 * b2) - (c2 * b1) / det
        return intersectionPoint;
    }

    private static boolean isParallel(double[] coefsOne, double[] coefsTwo) {
        double determinant = (coefsOne[0] * coefsTwo[1]) - (coefsTwo[0] * coefsOne[1]);
        return determinant == 0;
    }

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        double radius = scanner.nextDouble();
        int numOfLines = scanner.nextInt();

        double[] tempPointOfintersection;
        double[][] coefsTable = new double[numOfLines][]; //a table including all coefs of all equations
        for (int i = 0 ; i  < numOfLines ; i++) coefsTable[i] = new double[3];

        for (int i = 0 ; i < numOfLines ; i++){
            for (int j = 0 ; j < 3 ; j++){
                coefsTable[i][j] = scanner.nextDouble(); //getting all coefs of all equations
            }
        }

        int countOfIntersects = 0; //counter for points of intersections
        for (int i = 0; i < numOfLines; i++) {
            for (int k = i + 1; k < numOfLines; k++) {
                if (isParallel(coefsTable[i], coefsTable[k])) continue;
                else {
                    tempPointOfintersection = findIntersection(coefsTable[i], coefsTable[k]);
                    if (isInRadius(tempPointOfintersection, radius)) {
                        countOfIntersects++;
                    }
                }
            }
        }
        scanner.close();
        System.out.println(numOfLines + countOfIntersects + 1); // print number of areas
    }
}
