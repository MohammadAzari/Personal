import java.util.Scanner;
import java.util.regex.Pattern;

//this program was written by "Mohammad Azari" on AP course

public class EzProg {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String endChecker = "eod";
        String currentStr;
        Pattern pattern = Pattern.compile("\\d{2}:\\d{2} - \\d{2}:\\d{2} -> .+");
        boolean found;
        int[][] timeMatrix = new int[2][];
        for (int e = 0 ; e < 2 ; e++)
            timeMatrix[e] = new int[2];
        int hoursOfaDay = 23;
        int minutesOfanHour = 60;
        int tempHour;
        int tempMinute;
        int tempSwap;

        while (true){
            currentStr = scanner.nextLine();

            if (currentStr.equals(endChecker)) break;
            found = pattern.matcher(currentStr).matches();
            if (!found)
                System.out.println("Wrong input format");
            else {

                String[] firstSplit = currentStr.split(" -> ");
                String[] secondSplit = firstSplit[0].split(" - ");
                String[][] thirdSplit = new String[secondSplit.length][];
                for (int i = 0 ; i < 2 ; i++)
                    thirdSplit[i] = secondSplit[i].split(":");
                for (int i = 0 ; i < 2 ; i++){
                    for (int j = 0 ; j < 2 ; j++){
                        timeMatrix[i][j] = Integer.parseInt(thirdSplit[i][j]);
                    }
                }

                if (timeMatrix[0][0] >= timeMatrix[1][0] && timeMatrix[0][1] >= timeMatrix[1][1]) {
                    // for example in 12:00 - 11:00 , this if swap it.
                    tempSwap = timeMatrix[0][0];
                    timeMatrix[0][0] = timeMatrix[1][0];
                    timeMatrix[1][0] = tempSwap;

                    tempSwap = timeMatrix[0][1];
                    timeMatrix[0][1] = timeMatrix[1][1];
                    timeMatrix[1][1] = tempSwap;
                }

                tempHour = (timeMatrix[1][0] - timeMatrix[0][0]);
                tempMinute = (timeMatrix[1][1] - timeMatrix[0][1]);

                if (tempMinute < 0 && tempHour > 0){ //for example in 15:20 - 16:10
                    tempMinute = 60 - (timeMatrix[0][1] - timeMatrix[1][1]);
                    tempHour--;
                    hoursOfaDay -= tempHour;
                    minutesOfanHour -= tempMinute;
                    if (minutesOfanHour < 0){
                        minutesOfanHour += 60;
                        hoursOfaDay--;
                    }
                }

                else {
                    minutesOfanHour -= tempMinute;
                    hoursOfaDay -= tempHour;
                    if (minutesOfanHour < 0){
                        minutesOfanHour += 60;
                        hoursOfaDay--;
                    }
                }
            }

        }

        if (minutesOfanHour == 60){
            hoursOfaDay++;
            minutesOfanHour = 0;
        }

        scanner.close();
        System.out.printf("%02d:%02d", hoursOfaDay, minutesOfanHour);
    }
}