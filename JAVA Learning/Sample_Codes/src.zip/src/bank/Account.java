package bank;

public class Account {
    private int accountNumber;
    private double balance;
    private CreditCard creditCard;

    public Account(double balance, int accountNumber){
        this.balance = balance;
        this.accountNumber = accountNumber;
    }

    public void setCreditCard(CreditCard creditCard) {
        this.creditCard = creditCard;
    }

    public CreditCard getCreditCard() {
        return creditCard;
    }

    public double getBalance() {
        return balance;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void deposit(double balance){
        this.balance += balance;
    }
}
