package bank;

public class Customer {
    private String name;
    private Account account;
    private Branch customerBranch;
    private static int accountNumber = 1;
    private static int creditCardNumber = 0;

    public Customer(String name, double balance, boolean wantCreditCard, Branch branch){
        customerBranch = branch;
        customerBranch.customers.add(this);
        this.name = name;
        this.account = new Account(balance, accountNumber);
        accountNumber++;
        if (wantCreditCard) {
            this.account.setCreditCard(new CreditCard(creditCardNumber));
            creditCardNumber++;
            System.out.println(this.name +"     "+ this.account.getBalance() + "    " +
                    this.account.getAccountNumber() +"  "+ creditCardNumber +
                    "     Customers: " + customerBranch.customers.get(0).getName());
        }
        else
        System.out.println(this.name +"     "+ this.account.getBalance() + "    " + this.account.getAccountNumber() +"  "+ "don't have credit card!");
    }

    public Account getAccount() {
        return account;
    }

    public String getName() {
        return name;
    }
}
