package bank;

import java.util.ArrayList;

public class Branch {
    private String code;
    private String city;
    private int rate;
    public ArrayList<Customer> customers;

    public Branch(String code, String city, int rate){
        this.code = code;
        this.city = city;
        this.rate = rate;
        customers = new ArrayList<>();
        System.out.println("code: " + this.code +" "+ "city: " + this.city +" "+ "rate: " +this.rate);
    }

    public int getRate() {
        return rate;
    }

    public String getCity() {
        return city;
    }

    public String getCode() {
        return code;
    }
}
