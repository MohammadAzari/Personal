package bank;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;
        Branch branchOne = new Branch("b1", "Tehran", 1);
        Customer customerOne = new Customer("Ali", 50.00, true, branchOne);
        /*while (true){
            input = scanner.nextLine();
            if (input.equals("end")) break;
            else if(input.startsWith("add branch")){

            }
        }*/
        /*Branch branchOne = new Branch("b1", "Tehran", 1);
        Customer customerOne = new Customer("Reza", 50.50, true);
        branchOne.customers.add(customerOne);
        customerOne.getAccount().deposit(20);
        System.out.println(customerOne.getAccount().getBalance());
        Customer customerTwo = new Customer("Ali", 40, false);
        branchOne.customers.add(customerTwo);*/
    }
}
