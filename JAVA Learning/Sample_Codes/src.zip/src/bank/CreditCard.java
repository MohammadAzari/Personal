package bank;

public class CreditCard{
    private int cardNumber;

    public CreditCard(int cardNumber){
        this.cardNumber = cardNumber;
    }

    public int getCardNumber() {
        return cardNumber;
    }
}
